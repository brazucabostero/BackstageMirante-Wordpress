<?php

require_once INGS_FLUXO_COMPRA_INGRESSO_PATH . 'ingresse-api/ingresse.php';
require_once get_stylesheet_directory() . "/classes/mirante-event-list-table.php";
