<?php
/**
 * @var $payment_response
 */
?>

<div class="container">
  <?php if ($payment_response->responseData->data->status === 'declined' || empty($payment_response)): ?>
    <div class="row text-center">
      <svg style="height: 110px" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
           class="bi bi-x-circle-fill text-danger" viewBox="0 0 16 16">
        <path
          d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
      </svg>
      <h3>Pagamento recusado</h3>
    </div>
    <div class="row m-2 justify-content-center">
      <div class="col-4 text-center">
        <button class="btn btn-light btn-large rounded-pill" onclick="tryPaymentAgain()">
          Tentar com outro cartão
        </button>
      </div>
    </div>
  <?php elseif ($payment_response->responseError->code == '1031'): ?>
    <div class="row text-center">
      <svg style="height: 110px" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
           class="bi bi-x-circle-fill text-danger" viewBox="0 0 16 16">
        <path
          d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
      </svg>
      <h3>Pagamento recusado</h3>
    </div>
    <div class="row m-2 justify-content-center">
      <div class="col-4 text-center">
        <button class="btn btn-light btn-large rounded-pill" onclick="tryPaymentAgain()">
          Tentar com outro cartão
        </button>
      </div>
    </div>
  <?php elseif ($payment_response->responseData->data->status === 'approved'): ?>
    <div class="row text-center p-4 rounded" style="background: #76d371;">
      <h3 style="
          font-family: 'ENCODE SANS';
          font-size: 34px;
          font-weight: 700;
        ">
        Compra realizada com sucesso
      </h3>
    </div>
    <script>
      (() => {
        jQuery('#btn-payment').attr('href', '<?= get_site_url() ?>');
        jQuery('#btn-payment').html("Comprar mais ingressos");
        jQuery('#btn-payment').removeClass('d-none');
        window.removeEventListener('beforeunload', handleWindowExit);
      })();
    </script>
  <?php else: ?>
    <div class="row text-center">
      <svg style="height: 110px" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
           class="bi bi-x-circle-fill text-danger" viewBox="0 0 16 16">
        <path
          d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
      </svg>
      <h3>Pagamento recusado</h3>
    </div>
    <div class="row m-2 justify-content-center">
      <div class="col-4 text-center">
        <button class="btn btn-light btn-large rounded-pill" onclick="tryPaymentAgain()">
          Tentar com outro cartão
        </button>
      </div>
    </div>  
  <?php endif; ?>
</div>
