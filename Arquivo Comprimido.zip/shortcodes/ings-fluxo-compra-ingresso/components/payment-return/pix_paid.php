<?php
/**
 * @var $result
 */
?>

<div class="row text-center p-4 rounded" style="background: #76d371;">
  <h3 style="
          font-family: 'ENCODE SANS';
          font-size: 34px;
          font-weight: 700;
        ">
    Compra realizada com sucesso
  </h3>
</div>
<script>
  (() => {
    jQuery('#btn-payment').attr('href', '<?= get_site_url() ?>');
    jQuery('#btn-payment').removeClass('d-none');
    jQuery('#btn-payment').html("Comprar mais ingressos");
    window.removeEventListener('beforeunload', handleWindowExit);
  })();
</script>
