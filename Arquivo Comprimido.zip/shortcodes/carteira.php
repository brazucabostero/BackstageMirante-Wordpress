<!doctype html>
<html lang="en" ng-app="myTickets">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js">
  </script>
  <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular-cookies.js"></script>
  <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular-route.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/angular-i18n/1.8.2/angular-locale_pt-br.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      let x = new bootstrap.Carousel('#carouselExampleIndicators');
      //var myModal = new bootstrap.Modal(document.getElementById("modalUserTransfer"), {});
    });
  </script>
  <script>
    var app = angular.module('myTickets', ['ngCookies', 'ngRoute']);
    app.config(function($routeProvider) {
      $routeProvider.when("/", {
        template: `
        <div class="container">
          <div class="row">
            <div class="col-6 header-carteira">
                <p class="carteira">Carteira de ingressos</p>
            </div>
            <div class="col-6 header-buttons">
              <button type="button" ng-class="{'btn-active': prev}" class="btn-prev" ng-click="previousEvents()">Anteriores</button>
              <button type="button" ng-class="{'btn-active': next}" class="btn-next" ng-click="nextEvents()">Próximos</button>
            </div>
          </div>
          <div class="row">
              <div class="col-12 pendentes" ng-click="setEventsPending()" ng-if="showPending"><i class="bi bi-bell" style="float:none!important"></i>{{ticketsPendingMessage}}</div>
          </div>
            <div class="row container-events">
              <div class="col-12 events-null" ng-if="!eventsList.length > 0">Não existem eventos no momento</div>
              <div ng-click="detailEvent(event, event.sessions.data[0])" class="col-4 event" ng-repeat="event in eventsList">
                  <div class="row">
                      <div class="col-12 carteira-img-container"><img class="carteira-img-event" src="{{event.poster}}"></div>
                  </div>
                  <div class="row">
                      <div class="col-12 ingressos-container">
                          <div class="ingressos">{{event.tickets}} {{event.tickets > 1 ? 'ingressos' : 'ingresso'}} para este evento</div>
                      </div>
                  </div>
                  <div class="row infos-event date-event-list">
                      <div ng-click="detailEvent(event, session)" ng-repeat="session in event.sessions.data" class="date-event">
                        {{convertDataSession(session)}}
                      </div>
                      <div class="col-9">
                          <p class="event-name">{{ event.title }}</p>
                          <p class="event-time"><i class="bi bi-clock"></i>{{ event.sessions.data[0].datetime | date : "shortTime" }}</p>
                          <p class="event-local">
                            <svg width="12" height="16" viewBox="0 0 12 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M6.00006 8.67733V8.67733C4.75731 8.67733 3.75006 7.66121 3.75006 6.40751V6.40751C3.75006 5.15382 4.75731 4.1377 6.00006 4.1377V4.1377C7.24281 4.1377 8.25006 5.15382 8.25006 6.40751V6.40751C8.25006 7.66121 7.24281 8.67733 6.00006 8.67733Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                              <path fill-rule="evenodd" clip-rule="evenodd" d="M6.00006 14.7302C6.00006 14.7302 0.750061 10.3797 0.750061 6.40757C0.750061 3.48253 3.10056 1.11133 6.00006 1.11133C8.89956 1.11133 11.2501 3.48253 11.2501 6.40757C11.2501 10.3797 6.00006 14.7302 6.00006 14.7302Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                              {{event.venue.street}} - {{event.venue.city}}
                          </p>
                      </div>
                  </div>
              </div>
          </div>
        </div>
        <div class="container show-mobile">
          <div class="row" style="background:rgba(11,11,15,1)">
              <div class="col-12 header-carteira-mobile">
                  <p class="carteira-mobile">Carteira de ingressos</p>
              </div>
              <div class="col-12 header-buttons-mobile">
              //<button type="button" ng-class="{'btn-active-mobile': next}" class="btn-next-mobile" ng-click="nextEvents()">PRÓXIMOS</button><button type="button" ng-class="{'btn-active-mobile': prev}" class="btn-prev-mobile" ng-click="previousEvents()">ANTERIORES</button>
              </div>
          </div>
        </div>
        <div class="container show-mobile">
          <div class="row">
              <div class="events-mobile">
                  <div class="col-12 pendentes" ng-click="setEventsPending()" ng-if="showPending"><i class="bi bi-bell" style="float:none!important"></i>{{ticketsPendingMessage}}</div>
                  <div class="col-12 events-null" ng-if="!eventsList.length > 0">Não existem eventos no momento</div>
                  <div class="cold-12 event-mobile mt-5" ng-click="detailEvent(event)" ng-repeat="event in eventsList"><img src="{{event.poster}}" class="event-image-mobile">
                      <div class="row">
                          <div class="col-12">
                              <div class="ingressos-mobile">{{event.tickets}} {{event.tickets > 1 ? 'ingressos' : 'ingresso'}} para este evento</div>
                          </div>
                      </div>
                      <div class="event-infos-mobile">
                          <div class="row">
                              <div class="col-3">
                                  <div class="event-date-mobile">{{convertData(event.sessions)}}</div>
                              </div>
                              <div class="col-9">
                                  <p class="event-title-mobile">{{ event.title }}</p>
                                  <p class="event-datetime-mobile"><i class="bi bi-clock"></i>{{ timeConverted}}</p>
                                  <p class="event-location-mobile">
                                  <svg width="12" height="16" viewBox="0 0 12 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M6.00006 8.67733V8.67733C4.75731 8.67733 3.75006 7.66121 3.75006 6.40751V6.40751C3.75006 5.15382 4.75731 4.1377 6.00006 4.1377V4.1377C7.24281 4.1377 8.25006 5.15382 8.25006 6.40751V6.40751C8.25006 7.66121 7.24281 8.67733 6.00006 8.67733Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M6.00006 14.7302C6.00006 14.7302 0.750061 10.3797 0.750061 6.40757C0.750061 3.48253 3.10056 1.11133 6.00006 1.11133C8.89956 1.11133 11.2501 3.48253 11.2501 6.40757C11.2501 10.3797 6.00006 14.7302 6.00006 14.7302Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                  </svg>
                                   {{event.venue.street}} - {{event.venue.city}}
                                  </p>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>`,
        controller: 'MyTicketsController'
      }).when("/details-event/:id", {
        template: `<style>
            @media (max-width:767px) {
                .elementor-location-header {
                    display: none
                }

                .tickets-mobile {
                    height: auto;
                    min-height: 1000px
                }
            }
        </style>
        <div class="container show-wheb">
            <div class="row">
                <div class="col-12 back"><button type="button" class="btn btn-link btn-back" ng-click="back()"><i
                            class="bi bi-chevron-left"></i>Voltar</button></div>
            </div>
            <div class="row">
                <div class="col-2"><img src="{{eventSelected.poster}}"></div>
                <div class="col-10">
                    <p class="seus-ingressos">Seus ingressos para <strong>{{eventSelected.title}}</strong></p>
                    <p class="local"><i class="bi bi-geo-alt-fill"></i> {{eventSelected.venue.street}} - {{eventSelected.venue.city}}</p>
                    <div class="date-event-list">
                      <div ng-click="detailEvent(date)" ng-repeat="date in eventSelected.date" data-session="{{date.id}}" class="date-event-datail {{isActiveDate(date)}} ">
                          {{convertDataDetail(date)}}
                        </div>

                    </div>
                </div>
            </div>
            <div class="row ingressos-text">
                <div class="col-12">
                    <p class="disponiveis-text"> Ingressos disponíveis</p>
                </div>
            </div>
            <div class="accordion" id="accordionPanelsStayOpenExample">
                <div class="accordion-item" ng-repeat="ticket in ticketsFilter">
                    <h2 class="accordion-header" id="panelsStayOpen-heading{{$index}}">
                      <button class="accordion-button button-ingresso"
                            type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapse{{$index}}"
                             aria-controls="panelsStayOpen-collapse{{$index}}">
                             <div class="ings-tickets-sections">
                              <p class="pista">{{ticket.title}}</p>
                              <p class="pista">{{ticket.type}}</p>
                              <div>
                                <div class="btn-retornar" ng-click="returnTicket(ticket)" ng-if="ticket.isReturnable">
                                  <i class="bi bi-arrow-counterclockwise"></i>
                                </div>
                              </div>
                             </div>
                      </button>
                    </h2>
                    <div id="panelsStayOpen-collapse{{$index}}" class="accordion-collapse collapse"
                        aria-labelledby="panelsStayOpen-heading{{$index}}">
                        <div class="accordion-body">
                            <div class="row">
                                <div class="col-4 ">
                                    <p class="titular-text">Titular</p>
                                    <p class="titular-name">{{ticket.currentHolder.name}}</p>
                                </div>
                                <div class="col-4 ">
                                    <p class="cpf-text">{{user.identity.type.name}}</p>
                                    <p i class="cpf">{{user.identity.id}}</p>
                                </div>
                                <div class="col-4 ">
                                  <button ng-if="ticket.transferedTo.status === 'pending'" ng-click="transferCancelTicket(ticket)"
                                    class="btn btn-primary float-end btn-cancelar">CANCELAR TRANSFERÊNCIA
                                  </button>
                                  <button ng-if="!ticket.transferedTo && ticket.isTransferable" ng-click="setTicket(ticket)" class="btn btn-primary float-end btn-transferir" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                    <i class="bi bi-arrow-left-right"></i>
                                    Transferir
                                  </button>
                                  </div>
                            </div>
                            <div class="row">
                                <div class="col-12 qr-mobile"> <i class="bi bi-qr-code"></i> Consulte as versões mobile ou app
                                    para visualizar o QR Code </div>
                                <div class="col-12 container-qr"><img class="show-qr-code"
                                        src="https://chart.googleapis.com/chart?cht=qr&chs=200x200&chl={{ticket.code}}&coe=UTF-8">
                                </div>
                            </div>
<!--                            <div class="row"> -->
<!--                                <div class="col-12 infos" ng-bind-html="trustHtml(ticket.description)"></div>-->
<!--                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container show-mobile tickets-mobile">
            <div id="carouselExampleIndicators" class="carousel slide" data-bs-touch="true">
                <div class="carousel-indicators"><button ng-repeat="ticket in tickets" type="button"
                        data-bs-target="#carouselExampleIndicators" data-bs-slide-to="{{$index}}"
                        ng-class="{'active': $index == 0}" aria-current="true" aria-label="Slide {{$index}}"></button></div>
                <div class="carousel-inner">
                    <div class="carousel-item" ng-class="{'active': $index == 0}" ng-repeat="ticket in tickets"><button
                            ng-click="back()" type="button" class="btn-back-mobile"><i
                                class="bi bi-chevron-left"></i></button><img src="{{eventSelected.poster}}"
                            class="ticket-image-mobile">
                        <div class="ticket-info-mobile">
                            <div class="ticket-info-heade-mobile">
                                <div class="row">
                                    <div class="col-3">
                                        <div class="ticket-info-datetime-mobile">{{convertData(ticket.sessions)}}</div>
                                    </div>
                                    <div class="col-9">
                                        <p class="ticket-location-mobile">Allianz Parque - São Paulo</p>
                                        <p class="ticket-event-time">{{timeConverted}}</p><a href="#"
                                            ng-click="openMap(eventSelected.venue)" class="ticket-event-location">VER NO
                                            MAPA</a>
                                    </div>
                                    <div ng-if="!ticket.transferedTo || ticket.transferedTo.status === 'pending'" class="col-12 "><img class="show-qr-code ticket-qr-code-mobile"
                                            src="https://chart.googleapis.com/chart?cht=qr&chs=200x200&chl={{ticket.code}}&coe=UTF-8">
                                    </div>
                                    <div class="col-12 pt-4">
                                        <p class="ticket-setor-mobile">{{ticket.title}}</p>
                                    </div>
                                    <div class="col-6">
                                        <p class="titular-text">Titular</p>
                                        <p class="titular-name">{{ticket.currentHolder.name}}</p>
                                    </div>
                                    <div class="col-6">
                                        <p class="cpf-text">{{user.identity.type.name}}</p>
                                        <p class="cpf">{{user.identity.id}}</p>
                                    </div>
                                    <div class="col-12"><button ng-if="!ticket.transferedTo && ticket.isTransferable"
                                            ng-click="setTicket(ticket)" class="btn btn-primary btn-transferir-mobile"
                                            data-bs-toggle="modal" data-bs-target="#exampleModal">Transferir</button><button
                                            ng-if="ticket.transferedTo.status === 'pending'" ng-click="transferCancelTicket(ticket)"
                                            class="btn btn-primary btn-cancelar-mobile">CANCELAR TRANSFERÊNCIA</button></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><button class="carousel-control-prev" style="display: none;" type="button"
                    data-bs-target="#carouselExampleIndicators" data-bs-slide="prev"><span class="carousel-control-prev-icon"
                        aria-hidden="true"></span><span class="visually-hidden">Previous</span></button><button
                    class="carousel-control-next" style="display: none;" type="button"
                    data-bs-target="#carouselExampleIndicators" data-bs-slide="next"><span class="carousel-control-next-icon"
                        aria-hidden="true"></span><span class="visually-hidden">Next</span></button>
            </div>
        </div>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Transferir ingresso</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="form-inline" name="searchForm">
                            <div class="row">
                                <div class="col-12 ings-transfer-search">
                                    <div class="form-group">
                                        <input type="text" ng-model="search.email" required class="form-control campo-buscar"
                                            id="inputPassword2" placeholder="Pesquise ">
                                    </div>
                                
                                    <button type="submit" class="btn btn-primary btn-search"
                                        ng-click="searchUser(searchForm)">BUSCAR</button>
                                </div>
                            </div>
                            <div id="user-not-found" class="d-none" ng-if="users.length === 0">
                              Nenhum amigo encontrado
                            </div>
                            <div class="row list-users" ng-if="users.length > 0">
                                <div class="col-12 text-user-title">
                                    Usuários
                                </div>
                                <div class="col-12">
                                    <div class="row list-item" ng-repeat="user in users">
                                        <div class="col-4 user-name">
                                            Nome: {{user.name}}
                                        </div>
                                        <div class="col-4 user-email">
                                            {{user.email}}
                                        </div>
                                        <div class="col-4">
                                            <button type="submit" class="btn btn-primary btn-selecionar"
                                                ng-click="transferTicket(user)">SELECIONAR</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                    </div>
                </div>
            </div>
        </div>`,
        controller: 'DetailController'
      }).when("/pending", {
        template: '<div class="container show-wheb"><div class="row" style="margin-bottom: 0px;"><div class="col-12 topo-eventos"><p class="carteira">Carteira de ingressos</p></div></div><div class="row"><div class="col-12 pendentes" ng-click="setEventsPending()"><i class="bi bi-bell" style="float: none!important;"></i> {{ticketsPendingMessage}}</div></div><div class="row container-events"><div ng-click="detailEvent(event)" class="col-4 event" ng-repeat="event in eventsPending"><div class="row"><div class="col-12"><img class="carteira-img-event" src="{{event.event.poster}}"></div></div><div class="row infos-event"><div class="col-3 date-event">{{convertData(event.sessions)}}</div><div class="col-9"><p class="event-name">{{ event.event.title }}</p><p class="event-time"><i class="bi bi-clock"></i> {{ event.sessions.data[0].datetime | date :"shortTime" }}</p><p class="event-local"><svg width="12" height="16" viewBox="0 0 12 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.00006 8.67733V8.67733C4.75731 8.67733 3.75006 7.66121 3.75006 6.40751V6.40751C3.75006 5.15382 4.75731 4.1377 6.00006 4.1377V4.1377C7.24281 4.1377 8.25006 5.15382 8.25006 6.40751V6.40751C8.25006 7.66121 7.24281 8.67733 6.00006 8.67733Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path fill-rule="evenodd" clip-rule="evenodd" d="M6.00006 14.7302C6.00006 14.7302 0.750061 10.3797 0.750061 6.40757C0.750061 3.48253 3.10056 1.11133 6.00006 1.11133C8.89956 1.11133 11.2501 3.48253 11.2501 6.40757C11.2501 10.3797 6.00006 14.7302 6.00006 14.7302Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Allianz Parque - São Paulo</p></div></div></div></div></div><style>@media (max-width: 767px) {.undo-filter {width: 100%;height: 40px;padding: 4px 8px 4px 8px;border-radius: 4px;background: rgba(247, 160, 0, 1);color: white;border: none;margin-top: 20px;}}</style><div class="container show-mobile"><div class="row" style="background: rgba(11, 11, 15, 1);"><div class="col-12 header-carteira-mobile"><p class="carteira-mobile">Carteira de ingressos</p></div></div><div class="row" style="display: contents;"><div class="col-12" style="justify-content: center;"><button ng-click="backHome()" class="undo-filter">Desfazer filtro</button></div></div></div><div class="container show-mobile"><div class="row"><div class="events-mobile"><div class="col-12 pendentes" ng-click="setEventsPending()" ng-if="showPending"><i class="bi bi-bell" style="float: none!important;"></i> {{ticketsPendingMessage}}</div><div class="cold-12 event-mobile mt-5" ng-click="detailEvent(event)" ng-repeat="event in eventsPending"><img src="{{event.event.poster}}" class="event-image-mobile"><div class="event-infos-mobile"><div class="row"><div class="col-3"><div class="event-date-mobile">{{convertData(event.sessions)}}</div></div><div class="col-9"><p class="event-title-mobile">{{ event.event.title }}</p><p class="event-datetime-mobile"><i class="bi bi-clock"></i> {{ timeConverted }}</p><p class="event-location-mobile"><i class="bi bi-geo-alt-fill"></i> Allianz Parque - São Paulo</p></div></div></div></div></div></div></div>',
        controller: 'MyTicketsPendingController'
      }).when("/detail-pending/:id", {
        template: `<style>@media (max-width:767px){.elementor-location-header{display:none}.tickets-mobile{height:auto;min-height:1000px}}</style><div class="container show-wheb"><div class="row"><div class="col-12 back"><button type="button" class="btn btn-link btn-back" ng-click="back()"><i class="bi bi-chevron-left"></i>Voltar</button></div></div><div class="row"><div class="col-2"><img src="{{eventSelected.poster}}"></div><div class="col-10"><p class="seus-ingressos">Seus ingreesos para <strong>{{eventSelected.title}}</strong></p><p class="local"><i class="bi bi-geo-alt-fill"></i> Allianz Parque - São Paulo</p></div></div><div class="row ingressos-text"><div class="col-12"><p class="disponiveis-text"></p> Ingressos recebidos</div></div><div class="row list-tickets-pending" ng-repeat="ticket in ticketsList"><div class="col-4 ticket-pending"><p class="name-enviado-texto">Enviado por</p><p class="name-enviado">{{ticket.receivedFrom.name}}</p></div><div class="col-4 ticket-pending"><p class="name-ticket">{{ticket.ticket.name}}</p></div><div class="col-4 ticket-pending"><button type="button" class="btn-recusar" ng-click="setTicketRefuse(ticket)">RECUSAR</button><button type="button" class="btn-aceitar" ng-click="setTicketAccept(ticket)">ACEITAR</button><button type="button" class="btn-bell"><i class="bi bi-bell"></i></button></div></div></div><style>@media (max-width:767px){.seus-ingressos-mobile{font-family:Encode Sans!important;font-size:16px!important;font-weight:500!important;line-height:20px!important;letter-spacing:0em!important;text-align:center!important}.ingresso-pendente-mobile{font-family:Encode Sans;font-size:26px;font-weight:700;line-height:33px;letter-spacing:0em;text-align:center;text-transform:uppercase}.disponiveis-text-mobile{font-family:Encode Sans!important;font-size:18px!important;font-weight:600!important;line-height:23px!important;letter-spacing:0em!important;text-align:left!important;color:rgba(167,167,167)!important}.btn-recusar{width:122!important;height:49px!important;padding:12px 40px 12px 40px!important;border-radius:36px!important;gap:10px!important;font-family:Encode Sans!important;font-size:16px!important;font-weight:700!important;line-height:24px!important;letter-spacing:0em!important;text-align:left!important}.name-enviado-texto{font-family:Encode Sans!important;font-size:10px!important;font-weight:500!important;line-height:13px!important;letter-spacing:0em!important;text-align:left!important}.name-enviado{font-family:Encode Sans!important;font-size:12px!important;font-weight:600!important;line-height:15px!important;letter-spacing:0em!important;text-align:left!important}.name-ticket{font-family:Encode Sans!important;font-size:14px!important;font-weight:600!important;line-height:18px!important;letter-spacing:0em!important;text-align:center!important}.ingressos-text{margin-bottom:10px!important;margin-top:30px!important}.date-mobile-pendente{width:60px!important;height:100px!important;padding:14px!important;border-radius:45px!important;gap:10px!important;font-family:Encode Sans!important;font-size:16px!important;font-weight:700!important;line-height:24px!important;letter-spacing:0.1em!important;text-align:center!important;border:1px solid rgba(255,255,255,1)!important}.ticket-info-mobile{background:black!important;width:477px!important;height:100%!important;margin-top:-50px!important;border-radius:40px 40px 10px 10px!important;position:relative!important;min-height:700px!important}</style><div class="container show-mobile tickets-mobile"><div id="carouselExampleIndicators" class="carousel slide" data-bs-touch="true"><div class="carousel-indicators"><button ng-repeat="ticket in ticketsList" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="{{$index}}" ng-class="{'active': $index == 0}" aria-current="true" aria-label="Slide {{$index}}"></button></div><div class="carousel-inner"><div class="carousel-item" ng-class="{'active': $index == 0}" ng-repeat="ticket in ticketsList"><button ng-click="back()" type="button" class="btn-back-mobile"><i class="bi bi-chevron-left"></i></button><img src="{{eventSelected.poster}}" class="ticket-image-mobile"><div class="ticket-info-mobile"><div class="ticket-info-heade-mobile"><div class="row"><div class="col-12" style="text-align: center;"><p class="seus-ingressos-mobile">Seus ingreesos para </p><p class="ingresso-pendente-mobile">{{eventSelected.title}}</p></div><div class="col-12"><div class="date-mobile-pendente">SEX 16 JUN</div></div><div class="row ingressos-text"><div class="col-12"><p class="disponiveis-text-mobile">Ingressos recebidos</p></div></div><div class="row list-tickets-pending" style="height: auto;"><div class="col-5 ticket-pending"><p class="name-enviado-texto">Enviado por</p><p class="name-enviado">{{ticket.receivedFrom.name}}</p></div><div class="col-5 ticket-pending"><p class="name-ticket">{{eventSelected.title}}</p></div><div class="col-2"><button type="button" class="btn-bell"><i class="bi bi-bell"></i></button></div><hr><div class="col-6 ticket-pending"><button type="button" class="btn-recusar" ng-click="setTicketRefuse(ticket)">RECUSAR</button></div><div class="col-6 ticket-pending"><button type="button" class="btn-aceitar" ng-click="setTicketAccept(ticket)">ACEITAR</button></div></div></div></div></div></div><button class="carousel-control-prev" style="display: none;" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev"><span class="carousel-control-prev-icon" aria-hidden="true"></span><span class="visually-hidden">Previous</span></button><button class="carousel-control-next" style="display: none;" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next"><span class="carousel-control-next-icon" aria-hidden="true"></span><span class="visually-hidden">Next</span></button></div></div>`,
        controller: 'DetailPendingController'
      });
    });

    app.controller('MyTicketsController', ['$scope', '$rootScope', '$http', '$cookies', '$location', '$filter', function TicketsListController($scope, $rootScope, $http,
      $cookies, $location, $filter) {

      $scope.user = angular.fromJson($cookies.get('wp_ing_user'));
      var userId = $scope.user.userId;
      var apikey = 'tDgFYzwDkGVTxWeAgQxs73Hrs74CaNn2';
      var token = $scope.user.token;

      $scope.prev = false;
      $scope.next = false;

      $scope.convertDataSession = function(session) {
        $scope.dataConvertida = '';
        $scope.convertTime(session.datetime);
        $scope.dataConvertida = $filter('date')(session.datetime, 'EEE dd MMM', 'pt_BR');
        return $scope.dataConvertida;
      }

      $scope.convertData = function(datasPil) {
        $scope.dataConvertida = '';
        if (datasPil.data.length == 1) {
          $scope.convertTime(datasPil.data[0].datetime);
          $scope.dataConvertida = $filter('date')(datasPil.data[0].datetime, 'EEE dd MMM', 'pt_BR');
          return $scope.dataConvertida;

        } else {
          datasPil.data.forEach((element, index) => {
            var hoje = new Date().toDateString();
            var data2 = new Date(datasPil.data[index].datetime).toDateString();

            if (data2 > hoje) {
              $scope.dataConvertida = $filter('date')(datasPil.data[index].datetime, 'EEE dd MMM', 'pt_BR');
              $scope.convertTime(datasPil.data[index].datetime);
            } else if (hoje == data2) {
              $scope.dataConvertida = $filter('date')(datasPil.data[index].datetime, 'EEE dd MMM', 'pt_BR');
              $scope.convertTime(datasPil.data[index].datetime);
            } else {
              $scope.dataConvertida = $filter('date')(datasPil.data[index].datetime, 'EEE dd MMM', 'pt_BR');
              $scope.convertTime(datasPil.data[index].datetime);
            }
          });
          return $scope.dataConvertida;
        }
      }

      $scope.convertTime = function(time) {
        $scope.timeConverted = $filter('date')(time, 'hh:mm', 'pt_BR');
      }

      $scope.getEvents = function(order) {
        $http({
          method: 'GET',
          url: 'https://api.ingresse.com/user/' + userId + '/wallet?apikey=' + apikey +
            '' + order + '&pageSize=12&usertoken=' + token + ''
        }).then(function successCallback(response) {
          $scope.eventsList = response.data.responseData.data;
        }, function errorCallback(response) {
          console.log('Deu erro:', response);
        });
      }

      $scope.getEvents('&from=yesterday&order=ASC');

      $scope.previousEvents = function() {
        $scope.prev = true;
        $scope.next = false;
        $scope.getEvents('&to=yesterday&order=DESC');
        $scope.termSearch = 'DESC';
      }

      $scope.nextEvents = function() {
        $scope.next = true;
        $scope.prev = false;
        $scope.getEvents('&from=yesterday&order=ASC');
        $scope.termSearch = 'ASC';
      }

      $scope.detailEvent = function(event, session) {
        $location.url(`/details-event/${event.id}?session=${session.id}`);
      };

      $scope.getTicketsPending = function() {
        $scope.ticketsPendingMessage = '';
        $scope.showPending = false;
        $http({
          method: 'GET',
          url: 'https://api.ingresse.com/user/' + userId + '/transfers/?apikey=' + apikey +
            '&status=pending&usertoken=' + token + ''
        }).then(function successCallback(response) {
          $scope.ticketsPending = response.data.responseData;
          if ($scope.ticketsPending.paginationInfo.totalResults > 0) {
            $scope.showPending = true;
            if ($scope.ticketsPending.paginationInfo.totalResults == 1) {
              $scope.ticketsPendingMessage = 'Você possui ' + $scope.ticketsPending.paginationInfo.totalResults + ' ingresso pendente de aceite';
            } else if ($scope.ticketsPending.paginationInfo.totalResults > 1) {
              $scope.ticketsPendingMessage = 'Você possui ' + $scope.ticketsPending.paginationInfo.totalResults + ' ingressos pendente de aceite';
            }

          }
        }, function errorCallback(response) {
          console.log('Deu erro:', response);
        });
      }

      $scope.getTicketsPending();

      $scope.setEventsPending = function() {
        $location.path('/pending');
      }
    }]);

    app.controller('MyTicketsPendingController', ['$scope', '$rootScope', '$http', '$cookies', '$location', '$filter', function TicketsListController($scope, $rootScope, $http,
      $cookies, $location, $filter) {

      $scope.user = angular.fromJson($cookies.get('wp_ing_user'));
      var userId = $scope.user.userId;
      var apikey = 'tDgFYzwDkGVTxWeAgQxs73Hrs74CaNn2';
      var token = $scope.user.token;

      $scope.backHome = function() {
        $location.path('/');
      }

      $scope.detailEvent = function(evento) {
        $location.path('/detail-pending/' + evento.event.id);
        $rootScope.eventSelected = {
          event: event.event
        };
      };

      $scope.getEventsPending = function() {
        $scope.ticketsPendingMessage = '';
        $http({
          method: 'GET',
          url: 'https://api.ingresse.com/user/' + userId + '/transfers/?apikey=' + apikey +
            '&status=pending&usertoken=' + token + ''
        }).then(function successCallback(response) {
          $scope.ticketsPending = response.data.responseData;
          $scope.eventsPending = $scope.ticketsPending.data;
          if ($scope.ticketsPending.paginationInfo.totalResults > 0) {
            $rootScope.pending = true;
            if ($scope.ticketsPending.paginationInfo.totalResults == 1) {
              $scope.ticketsPendingMessage = 'Você possui ' + $scope.ticketsPending.paginationInfo.totalResults + ' ingresso pendente de aceite';
            } else if ($scope.ticketsPending.paginationInfo.totalResults > 1) {
              $scope.ticketsPendingMessage = 'Você possui ' + $scope.ticketsPending.paginationInfo.totalResults + ' ingressos pendente de aceite';
            }

          }
        }, function errorCallback(response) {
          console.log('Deu erro:', response);
        });
      }

      $scope.getEventsPending();

      $scope.setEventsPending = function() {
        $scope.events = $scope.ticketsPending.data;
      }

      $scope.convertDataSession = function(session) {
        scope.dataConvertida = '';
        $scope.convertTime(session.datetime);
        $scope.dataConvertida = $filter('date')(session.datetime, 'EEE dd MMM', 'pt_BR');
        return $scope.dataConvertida;
      }

      $scope.convertData = function(datasPil) {
        $scope.dataConvertida = '';
        if (datasPil.data.length == 1) {
          $scope.convertTime(datasPil.data[0].datetime);
          $scope.dataConvertida = $filter('date')(datasPil.data[0].datetime, 'EEE dd MMM', 'pt_BR');
          return $scope.dataConvertida;

        } else {
          datasPil.data.forEach((element, index) => {
            var hoje = new Date().toDateString();
            var data2 = new Date(datasPil.data[index].datetime).toDateString();

            if (data2 > hoje) {
              $scope.dataConvertida = $filter('date')(datasPil.data[index].datetime, 'EEE dd MMM', 'pt_BR');
              $scope.convertTime(datasPil.data[index].datetime);
            } else if (hoje == data2) {
              $scope.dataConvertida = $filter('date')(datasPil.data[index].datetime, 'EEE dd MMM', 'pt_BR');
              $scope.convertTime(datasPil.data[index].datetime);
            } else {
              $scope.dataConvertida = $filter('date')(datasPil.data[index].datetime, 'EEE dd MMM', 'pt_BR');
              $scope.convertTime(datasPil.data[index].datetime);
            }
          });
          return $scope.dataConvertida;
        }
      }

      $scope.convertTime = function(time) {
        $scope.timeConverted = $filter('date')(time, 'hh:mm', 'pt_BR');
      }
    }]);

    app.controller('DetailController', ['$scope', '$rootScope', '$http', '$cookies', '$location', '$routeParams', '$filter', '$sce', function TicketsListController($scope, $rootScope, $http,
      $cookies, $location, $routeParams, $filter, $sce) {
      $scope.user = angular.fromJson($cookies.get('wp_ing_user'));
      $scope.user.identity.id = toCpf($scope.user.identity.id);
      var userId = $scope.user.userId;
      var apikey = 'tDgFYzwDkGVTxWeAgQxs73Hrs74CaNn2';
      var token = $scope.user.token;

      $scope.convertData = function(datasPil) {
        $scope.dataConvertida = '';
        if (datasPil.data.length == 1) {
          $scope.convertTime(datasPil.data[0].datetime);
          $scope.dataConvertida = $filter('date')(datasPil.data[0].datetime, 'EEE dd MMM', 'pt_BR');
          return $scope.dataConvertida;

        } else {
          datasPil.data.forEach((element, index) => {
            var hoje = new Date().toDateString();
            var data2 = new Date(datasPil.data[index].datetime).toDateString();

            if (data2 > hoje) {
              $scope.dataConvertida = $filter('date')(datasPil.data[index].datetime, 'EEE dd MMM', 'pt_BR');
              $scope.convertTime(datasPil.data[index].datetime);
            } else if (hoje == data2) {
              $scope.dataConvertida = $filter('date')(datasPil.data[index].datetime, 'EEE dd MMM', 'pt_BR');
              $scope.convertTime(datasPil.data[index].datetime);
            } else {
              $scope.dataConvertida = $filter('date')(datasPil.data[index].datetime, 'EEE dd MMM', 'pt_BR');
              $scope.convertTime(datasPil.data[index].datetime);
            }
          });
          return $scope.dataConvertida;
        }
      }

      $scope.isActiveDate = function (date) {
        return date.id == $routeParams.session ? 'active' : ''
      }

      $scope.detailEvent = function(data) {
        $scope.ticketsFilter = $scope.tickets.filter((ticket) => ticket.sessions.data?.[0].id == data.id)
        jQuery('.date-event-datail').removeClass('active')
        jQuery(`.date-event-datail[data-session="${data.id}"]`).addClass('active')
      };

      $scope.convertDataDetail = function(datasPil) {
        $scope.dataConvertida = '';
        var partesDaData = datasPil.dateTime.date.split("/");
        var dia = parseInt(partesDaData[0], 10);
        var mes = parseInt(partesDaData[1], 10) - 1;
        var ano = parseInt(partesDaData[2], 10);

        var data = new Date(ano, mes, dia);
        $scope.dataConvertida = $filter('date')(data, 'EEE dd MMM', 'pt_BR');
        return $scope.dataConvertida;
      }

      $scope.convertTime = function(time) {
        $scope.timeConverted = $filter('date')(time, 'hh:mm', 'pt_BR');
      }

      $scope.trustHtml = function(text) {
        return $sce.trustAsHtml(text);
      }

      $scope.openMap = function(map) {
        window.open(`https://www.google.com/maps/dir/?api=1&travelmode=driving&layer=traffic&destination=${map.location[0]},${map.location[1]}`);
      }

      $scope.loadEvent = function() {
        $http({
          method: 'GET',
          url: 'https://api.ingresse.com/event/' + $routeParams.id + '?apikey=' + apikey
        }).then(function successCallback(response) {
          $scope.eventSelected = response.data.responseData;
          $scope.loadTickets();
          if (jQuery(".accordion-collapse").length === 1) {
            jQuery(".accordion-collapse").addClass('show') 
          }
          
        }, function errorCallback(response) {
          console.log('Deu erro:', response);
        });
      }
      $scope.search = {
        email: ''
      };

      $scope.loadEvent();

      $scope.loadTickets = function() {
        $http({
          method: 'GET',
          url: 'https://api.ingresse.com/user/' + userId + '/tickets?apikey=' + apikey +
            '&eventId=' + $scope.eventSelected.id + '&usertoken=' + token + ''
        }).then(function successCallback(response) {
          $scope.tickets = response.data.responseData.data
            .map((ticket) => {
              if (!ticket.currentHolder) {
                return {...ticket, currentHolder: $scope.user}
              }

              return ticket
            });
          
          $scope.ticketsFilter = $scope.tickets.filter((ticket) => ticket.sessions.data?.[0].id == $routeParams.session)


          document.body.style.overflow = "auto";
        }, function errorCallback(response) {
          console.log('Deu erro:', response);
        });
      }
      $scope.returnTicket = function(ticket) {
        $http({
          method: 'POST',
          url: 'https://api.ingresse.com/ticket/' + ticket.id + '/transfer?apikey=' + apikey + '&usertoken=' + token,
          headers: {
            accept: 'application/json',
            'content-type': 'application/json'
          },
          data: {
            isReturn: true
          }
        }).then(function successCallback(response) {
          $location.path('/');
        }, function errorCallback(response) {
          console.log('Deu errado envio ingresso:', response);
        });
      }

      $scope.back = function() {
        $location.path('/');
      }

      $scope.getTicketsPendingList = function() {
        $http({
          method: 'GET',
          url: 'https://api.ingresse.com/user/' + userId + '/transfers/?apikey=' + apikey +
            '&status=pending&usertoken=' + token + ''
        }).then(function successCallback(response) {
          console.log('Eventos pendentes para pegar ingressos:', response.data.responseData);
        }, function errorCallback(response) {
          console.log('Deu erro para pegar ingressos pendentes:', response);
        });
      }

      $scope.searchUser = function(form) {
        if (form.$valid) {
          var term = $scope.search.email;
          $http({
            method: 'GET',
            url: 'https://api.ingresse.com/search/transfer/user?size=20&apikey=' + apikey + '&term=' + term + '&usertoken=' + token
          }).then(function successCallback(response) {
            $scope.users = response.data.responseData;
            
            if (!$scope.users.length) {
              jQuery("#user-not-found").removeClass("d-none")
              return
            }

            jQuery("#user-not-found").addClass("d-none")
          }, function errorCallback(response) {
            console.log('Deu erro:', response);
          });
        }
      };

      $scope.setTicket = function(ticket) {
        $scope.users = [];
        $scope.search = {
          email: ''
        };
        $scope.ticketSelected = ticket.id;
        jQuery("#user-not-found").addClass("d-none")
        // document.onreadystatechange = function() {
        //   myModal.show();
        // };
      }

      $scope.transferTicket = function(user) {
        $http({
          method: 'POST',
          url: 'https://api.ingresse.com/ticket/' + $scope.ticketSelected + '/transfer?apikey=' + apikey + '&usertoken=' + token,
          headers: {
            accept: 'application/json',
            'content-type': 'application/json'
          },
          data: {
            isReturn: false,
            appRestricted: false,
            user: user.id
          }
        }).then(function successCallback(response) {
          var returnPost = response.data.responseData;

          jQuery('#exampleModal').modal('hide');
          //hide the modal

          jQuery('body').removeClass('modal-open');
          //modal-open class is added on body so it has to be removed

          jQuery('.modal-backdrop').remove();
          //need to remove div with modal-backdrop class

          $scope.loadTickets();
        }, function errorCallback(response) {
          console.log(response);
        });
      }

      $scope.transferCancelTicket = function(ticket) {
        $http({
          method: 'POST',
          url: 'https://api.ingresse.com/ticket/' + ticket.id + '/transfer/' + ticket.transferedTo.transferId + '/?apikey=' + apikey + '&usertoken=' + token,
          headers: {
            accept: 'application/json',
            'content-type': 'application/json'
          },
          data: {
            action: 'cancel',
            transferId: ticket.transferedTo.transferId
          }
        }).then(function successCallback(response) {
          var returnPost = response.data.responseData;
          $scope.loadTickets();
        }, function errorCallback(response) {
          console.log(response);
        });
      }
    }]);

    app.controller('DetailPendingController', ['$scope', '$rootScope', '$http', '$cookies', '$location', '$routeParams', function TicketsListController($scope, $rootScope, $http,
      $cookies, $location, $routeParams) {
      $scope.user = angular.fromJson($cookies.get('wp_ing_user'));
      var userId = $scope.user.userId;
      var apikey = 'tDgFYzwDkGVTxWeAgQxs73Hrs74CaNn2';
      var token = $scope.user.token;

      $scope.loadEvent = function() {
        $http({
          method: 'GET',
          url: 'https://api.ingresse.com/event/' + $routeParams.id + '?apikey=' + apikey
        }).then(function successCallback(response) {
          $scope.eventSelected = response.data.responseData;
          $scope.getTicketsPendingList();
        }, function errorCallback(response) {
          console.log('Deu erro:', response);
        });
      }

      $scope.loadEvent();
      $scope.search = {
        email: ''
      };

      $scope.back = function() {
        $location.path('/pending');
      }

      $scope.getTicketsPendingList = function() {
        $scope.ticketsList = [];
        $http({
          method: 'GET',
          url: 'https://api.ingresse.com/user/' + userId + '/transfers/?apikey=' + apikey +
            '&status=pending&usertoken=' + token + ''
        }).then(function successCallback(response) {
          $scope.ticketsList = response.data.responseData.data;
        }, function errorCallback(response) {
          console.log('Deu erro para pegar ingressos pendentes:', response);
        });
      }



      $scope.setTicketAccept = function(ticketPending) {
        $scope.statusTickect(ticketPending, 'accept');
      }

      $scope.setTicketRefuse = function(ticketPending) {
        $scope.statusTickect(ticketPending, 'refuse');
      }

      $scope.statusTickect = function(ticketPending, actionParam) {
        if (actionParam == 'return') {
          var data = {
            isReturn: true
          }
        } else {
          var data = {
            action: actionParam
          }
        }
        $http({
          method: 'POST',
          url: 'https://api.ingresse.com/ticket/' + ticketPending.ticket.id + '/transfer/' + ticketPending.id + '/?apikey=' + apikey + '&usertoken=' + token,
          headers: {
            accept: 'application/json',
            'content-type': 'application/json'
          },
          data: {
            action: actionParam
          }
        }).then(function successCallback(response) {
          var returnPost = response.data.paginationInfo;
          $location.path('/');
          $scope.getTicketsPendingList();
          console.log('Retorno envio ingresso', returnPost);
        }, function errorCallback(response) {
          console.log(response);
        });
      }
    }]);

    function toCpf(cpf) {
      let formatedCpf = cpf.replace(/\D/g,"")                    //Remove tudo o que não é dígito
      formatedCpf = formatedCpf.replace(/(\d{3})(\d)/,"$1.$2")       //Coloca um ponto entre o terceiro e o quarto dígitos
      formatedCpf = formatedCpf.replace(/(\d{3})(\d)/,"$1.$2")
      return formatedCpf.replace(/(\d{3})(\d{1,2})$/,"$1-$2")
    }
  </script>
  <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>-child/lib/css/carteira.css">
</head>

<body>
  <div ng-view></div>
  <div class="ings-carteira-infos">
    <article>
      <b>QR CODE</b>
      <p>Os ingressos válidos para verificação na entrada do evento estão disponíveis nos formatos mobile: navegador.</p>

      <b>DUPLICIDADE</b>
      <p>Estes ingressos serão aceitos uma única vez, nossos códigos são únicos e não podem ser duplicados.</p>
    </article>
    <article>
      <b>DOCUMENTAÇÃO</b>

      <p>Para sua segurança, lembre-se de trazer a documentação necessária (RG ou CNH) para comprovar sua identidade.<br>
      No caso de meia entrada, será obrigatório apresentar o documento que comprove o direito ao benefício. Na ausência de comprovante, a organização tem direito de cobrar a diferença do valor inteiro na entrada do evento.</p>
    </article>
  </div>
</body>

</html>