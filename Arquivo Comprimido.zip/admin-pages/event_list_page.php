<?php

if (!empty($_GET['action']) && $_GET['action'] === 'sync') {
  global $wpdb;

  $ingresse_api = new IngresseAPI();
  $eventsSearch = $ingresse_api->getAllEvents()->data->hits;
  $events = array_map(function ($event) {
    return $event->_source;
  }, $eventsSearch);
  $events_ids = array_map(function($event) {
    return $event->id;
  }, $events);

  update_option('ingresse_public_events', implode(', ', $events_ids));

  foreach ($events as $event) {
    $post_search = $wpdb->get_results("select * from {$wpdb->postmeta} where meta_key = 'mirante_event_id' and meta_value = '{$event->id}'");
    $post_exists = !empty($post_search);

    if ($post_exists) continue;

    $new_page = array(
      'post_title' => $event->title,
      'post_status' => 'publish',
      'post_type' => 'page',
    );

    $page_id = wp_insert_post($new_page);
    if (!is_wp_error($page_id)) {
      update_post_meta($page_id, '_elementor_template_type', 'page');
      update_post_meta($page_id, '_elementor_page_template', 'default');
      update_post_meta($page_id, 'mirante_event_id', $event->id);
      update_post_meta($page_id, 'mirante_event_city', $event->place->city);
      update_post_meta($page_id, 'mirante_event_street', $event->place->street);
      foreach ($event->sessions as $session) {
        add_post_meta($page_id, 'mirante_event_session_datetime', $session->dateTime);
      }
    }

  }
}

if (!empty($_GET['action']) && !empty($_GET['post']) && $_GET['action'] === 'delete') {
  wp_delete_post($_GET['post'], true);
}

$table = new Mirante_Event_List_Table();

?>

<style>
  #action {
    width: 110px;
  }
</style>

<div class="wrap">
  <h1 class="wp-heading-inline">
    <?= get_admin_page_title(); ?>
  </h1>
  <a href="<?php menu_page_url('event-list') ?>&action=sync" class="page-title-action">
    Sincronizar
  </a>

  <?php $table->display(); ?>
</div>
